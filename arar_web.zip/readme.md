## Web arar.uy
Los servicios extras están puestos mediantes links CDN. No hace falta descargar extras.
Se utiliza  5 mediante CDN.
Los links de CSS personalizado deben ir lego del css ingresado por CDN.